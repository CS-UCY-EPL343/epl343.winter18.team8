package LoginScreenGui;
 import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
 import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.event.ActionEvent;
 
 
public class MainController {
 @FXML
 private Label lblstatus;
 
 @FXML TextField txtusername;
 
 
 @FXML
 private TextField txtpassword;
 
 
 public void Login(ActionEvent event) throws IOException {
	 if (txtusername.getText().equals("user") && txtpassword.getText().equals("pass")) {
		 lblstatus.setText("Login Success");
		 Stage primaryStage = new Stage();
		 Parent root=FXMLLoader.load(getClass().getResource("Main Screen.fxml"));
			Scene scene = new Scene(root);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setTitle("Main Calendar");
			primaryStage.setScene(scene);
			primaryStage.show();
	 } else
	 {
		 lblstatus.setText("Login Fail");

		 
	 }

}
}
